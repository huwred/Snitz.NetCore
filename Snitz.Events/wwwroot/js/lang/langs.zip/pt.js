
$.fullCalendar.lang("pt", {
	buttonText: {
		month: "Mês",
		week: "Semana",
		day: "Dia",
		list: "Agenda"
	},
	allDayText: "Todo o dia",
	eventLimitText: "mais"
});
