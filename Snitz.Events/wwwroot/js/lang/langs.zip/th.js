
$.fullCalendar.lang("th", {
	buttonText: {
		month: "เดือน",
		week: "สัปดาห์",
		day: "วัน",
		list: "แผนงาน"
	},
	allDayText: "ตลอดวัน",
	eventLimitText: "เพิ่มเติม"
});
